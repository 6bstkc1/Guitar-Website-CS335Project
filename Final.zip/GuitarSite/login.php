!DOCTYPE html>
<html>

<head>
<title>Guitar Site Login</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

	<h1>Login!</h1>

	<button class='acc' onclick='back()'>Back</button>

	<form id="loginForm" onsubmit="checkUserAndPass(event); return false">

		<p>Username:</p>
		<input type="text" id="username" required> <br>

		<p>Password:</p>
		<input type="password" id="password" required> <br> <br> <input
			type="submit" id="loginButton" value="login">

	</form>

	<div id="errorBox"></div>
	<!-- Area to display potential password errors -->

	<script>
		function checkUserAndPass(event)
		{
			
			event.preventDefault();
			user = document.getElementById("username").value;
			
			password = document.getElementById("password").value;
			
			errors = document.getElementById("errorBox");
			
				var ajax = new XMLHttpRequest();
				ajax.open("GET", "controller.php?mode=login&user=" + user + "&pass=" + password, true);
				ajax.send();
				ajax.onreadystatechange = function()
				{
					if (ajax.readyState == 4 && ajax.status == 200)
					{
						var re = ajax.responseText;
						if (re == 0) //If the username exists, and the user entered their password correctly
						{
							window.location.href="view.php";
						}
						else if (re == 1) //If the username is not in the database
						{
							errors.innerHTML = "Sorry, that username is not in the database.";
						}
						else
						{
							errors.innerHTML = "Password is incorrect.";
						}
					}
				}
		}

		function back()
		{
			window.location.href = 'view.php';
		}
		
		</script>
		
<?php
?>
	</body>
</html>