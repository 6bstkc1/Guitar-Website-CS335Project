<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<h1>Checkout</h1>

<body>
<?php

 ?>
 
 <form class='checkout' onsubmit="buy(); return false;">
 	First Name: <input type='text' required pattern='[a-zA-Z]{3,}' 
 	title='Must have letters and more than 2 characters.'><br><br>
 	
 	Last Name: <input type='text' pattern='[a-zA-Z]{3,}' 
 	required title='Must have letters and have more than 2 characters.'><br><br>
 	
 	State: 
<select required>
	<option value="AZ">Arizona</option>
	<option value="CA">California</option>
	<option value="CO">Colorado</option>
	<option value="NV">Nevada</option>
	<option value="NM">New Mexico</option>
	<option value="TX">Texas</option>
	<option value="UT">Utah</option>
</select><br><br>				
			
 	City: <input type='text' pattern='[a-zA-Z]{3,}' 
 	required title='Must have letters and have more than 2 charaters.'><br><br>
 	
 	Address: <input type='text' pattern='[a-zA-Z0-9 ]{3,}' 
 	required title='Must have letters, numbers or spaces and have more than 2 characters.'><br><br>
 	
 	Zip: <input type='text'  pattern='[0-9]{5}' 
 	required title='Must have numbers only and have exactly 5 characters.'><br><br>
 	
 	Card Number (Doesn't Save, Visa Only): <input type='text' required pattern='4[0-9]{12}(?:[0-9]{3})?'><br><br>
 	
 	Check This To Confirm Purchase: <input type='checkbox' required
			title='Enter a 16 digit Visa card. No dashes.'><br><br>
 	
 	<input type="submit" value='Buy!'>
 </form>
 
 <script>
	function buy()
	{
		var ajax = new XMLHttpRequest();
		ajax.open("GET","controller.php?mode=bought",true);
		ajax.send();
		ajax.onreadystatechange = function()
		{
			if(ajax.readyState == 4 && ajax.status == 200)
			{
				window.location.href = "view.php";
			}	
		}
	}
 </script>
 
 </body>
 </html>