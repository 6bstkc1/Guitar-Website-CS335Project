<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<h1>My Cart</h1>

<div id='cart'></div>

<button class='acc' onclick='back()'>Back</button>

<?php 
    session_start();
    $user = $_SESSION['user'];
 ?>
 
<script>
function back()
{
	window.location.href = "view.php";
}

function getItems(user)
{
	var ajax = new XMLHttpRequest();
	var cart = document.getElementById("cart");
	ajax.open("GET","controller.php?mode=cart&user="+user,true);
	ajax.send();
	ajax.onreadystatechange = function()
	{
		if(ajax.readyState == 4 && ajax.status == 200)
		{
			var re = JSON.parse(ajax.responseText);
			
			if(re[0] == null) // empty
				cart.innerHTML = "It Appears You Haven't Bought Anything!";
			else
			{
				cart.innerHTML = "Found items!<br><hr>";
				len = re.length;
				var total = 0;
				for(i = 0; i < len; i++)
				{
					cart.innerHTML += "<div class='cartitem'>" + re[i]['brand'] + " "
					+ re[i]['name'] + " Price: $" + re[i]['price'] + "</div><hr>";
					total += parseFloat(re[i]['price']);
				}
				total = (total).toFixed(2);
				cart.innerHTML += "<br>Total Price: $" + total +"<br><br>";
				cart.innerHTML += "<button class='acc' onclick='checkout()'>Checkout</button>";
			}
		}	
	}
}	

function checkout()
{
	window.location.href = "checkout.php";
}

</script>

<?php
echo" <script>
    getItems('$user');
    </script>";
?>


</body>
</html>